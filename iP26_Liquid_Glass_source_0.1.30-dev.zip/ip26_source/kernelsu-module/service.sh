#!/system/bin/sh
# Intentionally no-op: all runtime view hooks belong to the LSPosed module.
MODDIR=${0%/*}
