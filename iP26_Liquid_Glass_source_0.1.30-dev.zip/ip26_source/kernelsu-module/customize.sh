#!/system/bin/sh
ui_print "*******************************"
ui_print " iP26 Liquid Glass - TECNO LI7"
ui_print "*******************************"
ui_print "This is a companion scaffold only."
ui_print "Install and enable the LSPosed APK separately."
ui_print "No SystemUI files are replaced."
