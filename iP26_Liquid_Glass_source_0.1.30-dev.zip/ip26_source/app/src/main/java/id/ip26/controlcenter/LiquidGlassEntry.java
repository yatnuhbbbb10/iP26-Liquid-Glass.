package id.ip26.controlcenter;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;

import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.Set;
import java.util.Map;
import java.util.WeakHashMap;
import java.lang.ref.WeakReference;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XC_MethodReplacement;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * Retains Transsion's original slider/controller objects, enables the vendor's
 * native vertical QcToggleSeekBar path, and styles only outer slider containers.
 */
public final class LiquidGlassEntry implements IXposedHookLoadPackage {
    private static final String SYSTEM_UI = "com.android.systemui";
    private static final String SEEK_LAYOUT =
            "com.transsion.systemui.controlcenter.widget.SeekLayout";
    private static final String BRIGHTNESS_VIEW =
            "com.transsion.systemui.widget.TrBrightnessSliderView";
    private static final String VOLUME_VIEW =
            "com.transsion.systemui.widget.VolumeSliderView";
    // Boolean values are intentional: storing a Drawable as the value of a
    // WeakHashMap<View, Drawable> can retain its View through Drawable.Callback.
    // The original drawable is already retained as layer 0 of the View background.
    // Weak values avoid a View -> background Drawable -> Drawable.Callback -> View
    // retention cycle while still letting us identify our own overlay precisely.
    private static final Map<View, WeakReference<GradientDrawable>> GLASS_OVERLAYS =
            Collections.synchronizedMap(new WeakHashMap<>());
    private static final Map<View, Boolean> GEOMETRY_PROBED =
            Collections.synchronizedMap(new WeakHashMap<>());
    private static final Map<View, Boolean> SEEK_LAYOUT_PROBED =
            Collections.synchronizedMap(new WeakHashMap<>());

    @Override public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) {
        if (!SYSTEM_UI.equals(lpparam.packageName)) return;
        // QcToggleSeekBar already implements the complete native vertical path:
        // Canvas rotation, swapped measurement/size and matching touch mapping.
        // Enabling its existing predicate is safer than rotating the View externally.
        hookNativeVerticalSeekBar(lpparam.classLoader);
        hookSliderInflation(lpparam.classLoader, BRIGHTNESS_VIEW);
        hookSliderInflation(lpparam.classLoader, VOLUME_VIEW);

        try {
            Class<?> seekClass = XposedHelpers.findClass(SEEK_LAYOUT, lpparam.classLoader);
            Class<?> centralSurfacesClass = XposedHelpers.findClass(
                    "com.android.systemui.statusbar.phone.CentralSurfaces", lpparam.classLoader);
            Method setSurfaces = seekClass.getDeclaredMethod(
                    "setCentralSurfaces", centralSurfacesClass);
            if (!ViewGroup.class.isAssignableFrom(seekClass)
                    || setSurfaces.getReturnType() != void.class
                    || Modifier.isStatic(setSurfaces.getModifiers())) {
                throw new NoSuchMethodException(
                        "SeekLayout must be a ViewGroup with instance void setCentralSurfaces(CentralSurfaces)");
            }
            XposedHelpers.findAndHookMethod(seekClass, "setCentralSurfaces",
                    centralSurfacesClass, new XC_MethodHook() {
                        @Override protected void afterHookedMethod(MethodHookParam param) {
                            if (!(param.thisObject instanceof View)) return;
                            View root = (View) param.thisObject;
                            postSafely(root, () -> {
                                try {
                                    styleSliderContainers(root);
                                    if (root instanceof ViewGroup) {
                                        installSeekLayoutProbe((ViewGroup) root);
                                    }
                                } catch (Throwable t) {
                                    XposedBridge.log("iP26: SeekLayout post-style failed safely: " + t);
                                }
                            }, "SeekLayout");
                        }
                    });
            XposedBridge.log("iP26: SeekLayout hook installed");
        } catch (Throwable t) {
            XposedBridge.log("iP26: hook install failed: " + t);
        }
    }

    private static void hookNativeVerticalSeekBar(ClassLoader classLoader) {
        try {
            // Fail closed if a ROM update changes the owner, method shape, or
            // static/return contract. The inspected LI7 APK exposes this exact
            // predicate as public static boolean isQSCenterSupport().
            Class<?> predicateOwner = XposedHelpers.findClass(
                    "kotlin.io.CloseableKt", classLoader);
            Method predicate = predicateOwner.getDeclaredMethod("isQSCenterSupport");
            if (!Modifier.isStatic(predicate.getModifiers())
                    || predicate.getReturnType() != boolean.class) {
                throw new NoSuchMethodException(
                        "isQSCenterSupport must remain static boolean with no arguments");
            }
            XposedBridge.log("iP26: vertical predicate verified; ownerLoader="
                    + predicateOwner.getClassLoader());
            XposedHelpers.findAndHookMethod(predicateOwner,
                    "isQSCenterSupport",
                    new XC_MethodReplacement() {
                        @Override protected Object replaceHookedMethod(MethodHookParam param) {
                            return Boolean.TRUE;
                        }
                    });
            XposedBridge.log("iP26: native QcToggleSeekBar vertical path enabled");
        } catch (Throwable t) {
            // A failed preflight/hook leaves the vendor's own default behavior
            // untouched; do not crash SystemUI or rotate the View as a fallback.
            XposedBridge.log("iP26: vertical-mode hook unavailable; vendor default retained: " + t);
        }
    }

    private static void hookSliderInflation(ClassLoader classLoader, String className) {
        try {
            Class<?> sliderClass = XposedHelpers.findClass(className, classLoader);
            // The inspected vendor DEX declares onFinishInflate() on both slider
            // classes. Require that exact declaration: resolving an inherited View
            // method could accidentally hook the base class for every View instance.
            Method inflate = sliderClass.getDeclaredMethod("onFinishInflate");
            if (!View.class.isAssignableFrom(sliderClass)
                    || inflate.getReturnType() != void.class
                    || Modifier.isStatic(inflate.getModifiers())) {
                throw new NoSuchMethodException(
                        className + " must declare instance void onFinishInflate()");
            }
            XposedHelpers.findAndHookMethod(sliderClass, "onFinishInflate",
                    new XC_MethodHook() {
                        @Override protected void afterHookedMethod(MethodHookParam param) {
                            if (param.thisObject instanceof View) {
                                View slider = (View) param.thisObject;
                                postSafely(slider, () -> {
                                    try {
                                        applyGlassCard(slider);
                                    } catch (Throwable t) {
                                        XposedBridge.log("iP26: slider style failed safely for "
                                                + className + ": " + t);
                                    }
                                }, className);
                            }
                        }
                    });
            XposedBridge.log("iP26: verified and hooked declared onFinishInflate for " + className);
        } catch (Throwable t) {
            XposedBridge.log("iP26: inflation hook unavailable for " + className
                    + "; vendor behavior retained: " + t);
        }
    }

    private static void postSafely(View view, Runnable task, String label) {
        try {
            if (!view.post(task)) {
                XposedBridge.log("iP26: post rejected for " + label + "; no UI change applied");
            }
        } catch (Throwable t) {
            XposedBridge.log("iP26: post failed safely for " + label + ": " + t);
        }
    }

    /**
     * Capture the runtime-selected resource configuration and the direct child
     * geometry of SeekLayout. This is deliberately observational: resource
     * qualifiers in resources.arsc can differ by orientation and screen width,
     * so source defaults must not be treated as the active device dimensions.
     */
    private static void installSeekLayoutProbe(final ViewGroup seekLayout) {
        synchronized (SEEK_LAYOUT_PROBED) {
            if (SEEK_LAYOUT_PROBED.containsKey(seekLayout)) return;
            SEEK_LAYOUT_PROBED.put(seekLayout, Boolean.TRUE);
        }
        final View.OnLayoutChangeListener[] holder = new View.OnLayoutChangeListener[1];
        holder[0] = (view, left, top, right, bottom, oldLeft, oldTop, oldRight, oldBottom) -> {
            if (view.getWidth() <= 0 || view.getHeight() <= 0) return;
            view.removeOnLayoutChangeListener(holder[0]);
            logSeekLayout(seekLayout, "post-layout");
        };
        seekLayout.addOnLayoutChangeListener(holder[0]);
        seekLayout.post(() -> {
            if (seekLayout.getWidth() > 0 && seekLayout.getHeight() > 0) {
                seekLayout.removeOnLayoutChangeListener(holder[0]);
                logSeekLayout(seekLayout, "already-laid-out");
            }
        });
    }

    private static void logSeekLayout(ViewGroup seekLayout, String phase) {
        try {
            Configuration config = seekLayout.getResources().getConfiguration();
            android.util.DisplayMetrics metrics =
                    seekLayout.getResources().getDisplayMetrics();
            String orientation = config.orientation == Configuration.ORIENTATION_LANDSCAPE
                    ? "landscape" : config.orientation == Configuration.ORIENTATION_PORTRAIT
                    ? "portrait" : "undefined";
            XposedBridge.log("iP26: SeekLayout " + phase + " " + describeView(seekLayout)
                    + " config=" + orientation
                    + " screen=" + config.screenWidthDp + "x" + config.screenHeightDp + "dp"
                    + " smallestWidth=" + config.smallestScreenWidthDp + "dp"
                    + " density=" + metrics.density + " densityDpi=" + metrics.densityDpi);
            logRuntimeDimensions(seekLayout);
            for (int i = 0; i < seekLayout.getChildCount(); i++) {
                View child = seekLayout.getChildAt(i);
                XposedBridge.log("iP26: SeekLayout child[" + i + "] " + describeView(child)
                        + " lp=" + describeLayoutParams(child.getLayoutParams()));
            }
        } catch (Throwable t) {
            XposedBridge.log("iP26: SeekLayout diagnostic failed: " + t);
        }
    }

    private static void logRuntimeDimensions(View view) {
        String[] names = {
                "tr_brightness_slider_size", "tr_volume_slider_size",
                "ts_qc_seekbar_width", "ts_qc_seekbar_height",
                "qc_fixed_area_item_width", "qc_fixed_area_item_height",
                "resident_big_resident_tile_height_size",
                "ts_qc_big_tiles_gap_for_portrait",
                "ts_qc_big_tiles_gap_for_landscape",
                "ts_qc_seekbar_volume_margin_bottom", "tr_volume_min_height"
        };
        String packageName = view.getContext().getPackageName();
        float density = view.getResources().getDisplayMetrics().density;
        for (String name : names) {
            int id = view.getResources().getIdentifier(name, "dimen", packageName);
            if (id == 0) continue;
            try {
                float px = view.getResources().getDimension(id);
                XposedBridge.log("iP26: runtime dimen " + name + "="
                        + (px / density) + "dp (" + px + "px)");
            } catch (Throwable t) {
                XposedBridge.log("iP26: runtime dimen read failed " + name + ": " + t);
            }
        }
    }

    private static void styleSliderContainers(View root) {
        Set<View> visited = Collections.newSetFromMap(new IdentityHashMap<>());
        walk(root, visited);
    }

    private static void walk(View view, Set<View> visited) {
        if (view == null || !visited.add(view)) return;
        String name = view.getClass().getName();
        if (BRIGHTNESS_VIEW.equals(name) || VOLUME_VIEW.equals(name)) {
            applyGlassCard(view);
        }
        if (view instanceof ViewGroup) {
            ViewGroup group = (ViewGroup) view;
            for (int i = 0; i < group.getChildCount(); i++) {
                walk(group.getChildAt(i), visited);
            }
        }
    }

    /**
     * Attach a one-shot geometry probe. Layout dimensions are only meaningful
     * after Android has completed measurement/layout; logging during inflation
     * would otherwise report zeroes and lead to incorrect sizing decisions.
     */
    private static void installGeometryProbe(final ViewGroup slider) {
        synchronized (GEOMETRY_PROBED) {
            if (GEOMETRY_PROBED.containsKey(slider)) return;
            GEOMETRY_PROBED.put(slider, Boolean.TRUE);
        }
        final View.OnLayoutChangeListener[] holder = new View.OnLayoutChangeListener[1];
        holder[0] = (view, left, top, right, bottom, oldLeft, oldTop, oldRight, oldBottom) -> {
            if (view.getWidth() <= 0 || view.getHeight() <= 0) return;
            view.removeOnLayoutChangeListener(holder[0]);
            logSliderGeometry(slider, "post-layout");
        };
        slider.addOnLayoutChangeListener(holder[0]);
        // Covers the case where the listener is installed after the first layout.
        slider.post(() -> {
            if (slider.getWidth() > 0 && slider.getHeight() > 0) {
                slider.removeOnLayoutChangeListener(holder[0]);
                logSliderGeometry(slider, "already-laid-out");
            }
        });
    }

    private static void logSliderGeometry(ViewGroup slider, String phase) {
        try {
            ViewGroup.LayoutParams lp = slider.getLayoutParams();
            ViewParentInfo parentInfo = describeParent(slider);
            XposedBridge.log("iP26: " + phase + " " + describeView(slider)
                    + " layoutParams=" + describeLayoutParams(lp)
                    + " parent=" + parentInfo.description);
            logSeekbarDescendants(slider);
        } catch (Throwable t) {
            XposedBridge.log("iP26: geometry diagnostic failed: " + t);
        }
    }

    private static final class ViewParentInfo {
        final String description;
        ViewParentInfo(String description) { this.description = description; }
    }

    private static ViewParentInfo describeParent(View view) {
        // Capture the complete short ancestor chain: the immediate parent alone
        // cannot explain how SeekLayout is positioned inside the fixed area.
        StringBuilder chain = new StringBuilder();
        android.view.ViewParent parent = view.getParent();
        int depth = 0;
        while (parent instanceof View && depth < 6) {
            View parentView = (View) parent;
            if (chain.length() > 0) chain.append(" <- ");
            String orientation = "n/a";
            if (parentView instanceof android.widget.LinearLayout) {
                int value = ((android.widget.LinearLayout) parentView).getOrientation();
                orientation = value == android.widget.LinearLayout.VERTICAL
                        ? "vertical" : "horizontal";
            }
            chain.append(parentView.getClass().getName())
                    .append("[").append(resourceName(parentView)).append("]")
                    .append(" size=").append(parentView.getWidth()).append("x")
                    .append(parentView.getHeight())
                    .append(" measured=").append(parentView.getMeasuredWidth()).append("x")
                    .append(parentView.getMeasuredHeight())
                    .append(" orientation=").append(orientation)
                    .append(" lp=").append(describeLayoutParams(parentView.getLayoutParams()));
            parent = parentView.getParent();
            depth++;
        }
        return new ViewParentInfo(chain.length() == 0 ? "none" : chain.toString());
    }

    private static String resourceName(View view) {
        int id = view.getId();
        if (id == View.NO_ID) return "no-id";
        try { return view.getResources().getResourceEntryName(id); }
        catch (Throwable ignored) { return "id-0x" + Integer.toHexString(id); }
    }

    private static void logSeekbarDescendants(View view) {
        if (!(view instanceof ViewGroup)) return;
        ViewGroup group = (ViewGroup) view;
        for (int i = 0; i < group.getChildCount(); i++) {
            View child = group.getChildAt(i);
            String name = child.getClass().getName();
            if (name.endsWith("QcToggleSeekBar")) {
                ViewGroup.LayoutParams childLp = child.getLayoutParams();
                String orientation = "n/a";
                if (child instanceof android.widget.LinearLayout) {
                    int value = ((android.widget.LinearLayout) child).getOrientation();
                    orientation = value == android.widget.LinearLayout.VERTICAL
                            ? "vertical" : "horizontal";
                }
                XposedBridge.log("iP26: native seekbar " + describeView(child)
                        + " rotation=" + child.getRotation()
                        + " orientation=" + orientation
                        + " visibility=" + child.getVisibility()
                        + " alpha=" + child.getAlpha()
                        + " clickable=" + child.isClickable()
                        + " layoutParams=" + describeLayoutParams(childLp));
            }
            logSeekbarDescendants(child);
        }
    }


    private static String describeView(View view) {
        String idName = "no-id";
        int id = view.getId();
        if (id != View.NO_ID) {
            try {
                idName = view.getResources().getResourceEntryName(id);
            } catch (Throwable ignored) {
                idName = "id-0x" + Integer.toHexString(id);
            }
        }
        float density = view.getResources().getDisplayMetrics().density;
        return view.getClass().getName() + "[" + idName + "]"
                + " size=" + view.getWidth() + "x" + view.getHeight()
                + " measured=" + view.getMeasuredWidth() + "x" + view.getMeasuredHeight()
                + " dp=" + Math.round(view.getWidth() / density) + "x"
                + Math.round(view.getHeight() / density)
                + " padding=" + view.getPaddingLeft() + "," + view.getPaddingTop()
                + "," + view.getPaddingRight() + "," + view.getPaddingBottom();
    }

    private static String describeLayoutParams(ViewGroup.LayoutParams lp) {
        if (lp == null) return "null";
        String value = lp.width + "x" + lp.height;
        if (lp instanceof ViewGroup.MarginLayoutParams) {
            ViewGroup.MarginLayoutParams mlp = (ViewGroup.MarginLayoutParams) lp;
            value += " margins=" + mlp.leftMargin + "," + mlp.topMargin
                    + "," + mlp.rightMargin + "," + mlp.bottomMargin;
        }
        return value;
    }

    private static void applyGlassCard(View view) {
        float density = view.getResources().getDisplayMetrics().density;
        final boolean volumeCard = VOLUME_VIEW.equals(view.getClass().getName());
        GradientDrawable glass = new GradientDrawable();
        configureGlassOverlay(glass, density, volumeCard);

        Drawable current = view.getBackground();
        GradientDrawable previousOverlay = null;
        synchronized (GLASS_OVERLAYS) {
            WeakReference<GradientDrawable> ref = GLASS_OVERLAYS.get(view);
            if (ref != null) previousOverlay = ref.get();
        }

        boolean reusedOverlay = false;
        if (previousOverlay != null && containsDrawableIdentity(current, previousOverlay)) {
            // Transsion may wrap or recompose a background into nested
            // LayerDrawables between Control Center openings. Search by identity
            // through nested layers so our existing glass is updated in place
            // instead of being wrapped again on every recreation.
            configureGlassOverlay(previousOverlay, density, volumeCard);
            reusedOverlay = true;
        }

        // If the View originally had no background, the glass drawable is the
        // background itself (not a LayerDrawable). Recognize that exact object
        // and update it in place instead of wrapping another copy on each hook.
        if (!reusedOverlay && previousOverlay != null && current == previousOverlay) {
            configureGlassOverlay(previousOverlay, density, volumeCard);
            reusedOverlay = true;
        }

        if (!reusedOverlay) {
            Drawable original = cloneBackgroundPreservingRuntimeState(current, view);
            // Preserve the vendor background and its active state underneath the
            // translucent overlay. If it has no ConstantState, retain the original
            // instance rather than mutating a vendor-owned drawable in place.
            if (original == null) {
                view.setBackground(glass);
            } else {
                view.setBackground(new LayerDrawable(new Drawable[]{original, glass}));
            }
            synchronized (GLASS_OVERLAYS) {
                GLASS_OVERLAYS.put(view, new WeakReference<>(glass));
            }
            // Reveal only a newly installed overlay. Repeated lifecycle callbacks
            // update the same drawable without replaying the animation or touching
            // the vendor slider's alpha, scale, touch target, or controller.
            animateGlassReveal(view, glass);
        }

        // A restrained elevation keeps the card distinct without creating a large
        // shadow that would obscure the native Control Center layout.
        view.setElevation((volumeCard ? 4.5f : 4f) * density);
        view.setClipToOutline(false);
        if (view instanceof ViewGroup) {
            ViewGroup sliderGroup = (ViewGroup) view;
            sliderGroup.setClipChildren(false);
            sliderGroup.setClipToPadding(false);
            installGeometryProbe(sliderGroup);
        }
    }


    /**
     * Fade in the glass layer itself, not the View. This keeps the original
     * brightness/volume widget, labels, seekbar thumb and touch dispatch fully
     * opaque and interactive while giving a restrained Liquid Glass entrance.
     * The animator is started only while attached and is cancelled on detach.
     */
    private static void animateGlassReveal(final View view, final GradientDrawable overlay) {
        overlay.setAlpha(0);
        final ValueAnimator animator = ValueAnimator.ofInt(0, 255);
        animator.setDuration(240L);
        animator.setInterpolator(new DecelerateInterpolator());
        // Animator callbacks are normally serialized on the main thread, but a
        // terminal guard also makes a queued/late update harmless after cancel or
        // end. Identity checks alone are insufficient when the same overlay is
        // still installed but its previous animator has already been cancelled.
        final boolean[] terminal = { false };
        animator.addUpdateListener(value -> {
            if (terminal[0]) return;
            if (!isGlassOverlayCurrent(view, overlay)) {
                terminal[0] = true;
                value.cancel();
                return;
            }
            overlay.setAlpha((Integer) value.getAnimatedValue());
            overlay.invalidateSelf();
        });

        final boolean[] started = { false };
        final View.OnAttachStateChangeListener attachListener =
                new View.OnAttachStateChangeListener() {
                    @Override public void onViewAttachedToWindow(View attached) {
                        if (started[0]) return;
                        if (!isGlassOverlayCurrent(view, overlay)) {
                            terminal[0] = true;
                            attached.removeOnAttachStateChangeListener(this);
                            return;
                        }
                        started[0] = true;
                        animator.start();
                    }
                    @Override public void onViewDetachedFromWindow(View detached) {
                        if (animator.isStarted()) animator.cancel();
                        detached.removeOnAttachStateChangeListener(this);
                    }
                };
        animator.addListener(new AnimatorListenerAdapter() {
            @Override public void onAnimationEnd(Animator animation) {
                terminal[0] = true;
                view.removeOnAttachStateChangeListener(attachListener);
            }
            @Override public void onAnimationCancel(Animator animation) {
                terminal[0] = true;
                // Detaching a card mid-fade must not leave its glass permanently
                // translucent/partially hidden when the same View is reattached.
                // If our overlay is still the active background layer, settle it
                // at its final alpha; if the vendor replaced it, leave that new
                // background entirely untouched.
                if (isGlassOverlayCurrent(view, overlay)) {
                    overlay.setAlpha(255);
                    overlay.invalidateSelf();
                }
                view.removeOnAttachStateChangeListener(attachListener);
            }
        });

        if (view.isAttachedToWindow()) {
            if (isGlassOverlayCurrent(view, overlay)) {
                started[0] = true;
                animator.start();
            } else {
                terminal[0] = true;
            }
        } else {
            view.addOnAttachStateChangeListener(attachListener);
        }
    }

    private static boolean isGlassOverlayCurrent(View view, GradientDrawable overlay) {
        synchronized (GLASS_OVERLAYS) {
            WeakReference<GradientDrawable> ref = GLASS_OVERLAYS.get(view);
            if (ref == null || ref.get() != overlay) return false;
        }
        return containsDrawableIdentity(view.getBackground(), overlay);
    }


    /**
     * Search nested LayerDrawables by identity. Drawable equality is not enough:
     * two visually identical vendor layers must never be mistaken for our layer.
     */
    private static boolean containsDrawableIdentity(Drawable root, Drawable target) {
        // Drawable graphs are normally trees, but vendor wrappers are not required
        // to be acyclic. Track object identity so a malformed/cyclic wrapper cannot
        // recurse forever on the SystemUI main thread.
        Set<Drawable> visited = Collections.newSetFromMap(
                new IdentityHashMap<Drawable, Boolean>());
        return containsDrawableIdentity(root, target, visited);
    }

    private static boolean containsDrawableIdentity(
            Drawable root, Drawable target, Set<Drawable> visited) {
        if (root == null || target == null) return false;
        if (root == target) return true;
        if (!visited.add(root) || !(root instanceof LayerDrawable)) return false;
        LayerDrawable layers = (LayerDrawable) root;
        for (int i = 0; i < layers.getNumberOfLayers(); i++) {
            if (containsDrawableIdentity(layers.getDrawable(i), target, visited)) return true;
        }
        return false;
    }

    /** Clone when possible and copy the runtime state often lost by newDrawable(). */
    private static Drawable cloneBackgroundPreservingRuntimeState(Drawable current, View view) {
        if (current == null) return null;
        Drawable.ConstantState state = current.getConstantState();
        if (state == null) return current;
        Drawable copy = state.newDrawable(view.getResources()).mutate();
        copy.setBounds(current.getBounds());
        copy.setLevel(current.getLevel());
        copy.setState(current.getState());
        copy.setVisible(current.isVisible(), false);
        copy.setAlpha(current.getAlpha());
        return copy;
    }

    private static void configureGlassOverlay(
            GradientDrawable glass, float density, boolean volumeCard) {
        glass.setShape(GradientDrawable.RECTANGLE);
        glass.setCornerRadius((volumeCard ? 22f : 24f) * density);
        glass.setOrientation(GradientDrawable.Orientation.TOP_BOTTOM);
        // Keep the two controls visually distinguishable without replacing their
        // native track/thumb drawables or intercepting their touch/controller path.
        if (volumeCard) {
            glass.setColors(new int[]{
                    Color.argb(70, 220, 238, 255),
                    Color.argb(30, 166, 204, 244),
                    Color.argb(46, 235, 246, 255)
            });
            glass.setStroke(Math.max(1, Math.round(0.9f * density)),
                    Color.argb(104, 218, 238, 255));
        } else {
            glass.setColors(new int[]{
                    Color.argb(66, 255, 255, 255),
                    Color.argb(27, 232, 237, 246),
                    Color.argb(42, 255, 255, 255)
            });
            glass.setStroke(Math.max(1, Math.round(0.8f * density)),
                    Color.argb(92, 255, 255, 255));
        }
        glass.invalidateSelf();
    }
}
