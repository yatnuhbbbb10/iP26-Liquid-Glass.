# iP26 Liquid Glass — TECNO LI7

Experimental LSPosed source project for the Transsion Control Center on TECNO LI7 / Android 15 / HiOS 15.1.2.170. Current source version: **0.1.30-dev**.

This is development source only. It is not a compiled APK and the KernelSU folder is an inert scaffold, not a flashable implementation. Do not replace `TranSystemUI.apk`.

The vendor `QcToggleSeekBar` contains a native vertical rendering, measurement, layout-size, and touch-coordinate path. The source hooks the vendor predicate only after checking that the runtime method still exists with the inspected `static boolean ()` signature. If the check or hook fails, the source logs the failure and leaves vendor behavior untouched. This is a compatibility guard, not proof that the hook is safe on every HiOS build.

The current glass treatment is a translucent gradient/stroke overlay with rounded corners and elevation. It is **not** true backdrop blur. Brightness/volume controller objects, listeners, progress and native touch handling are intentionally retained.

See `docs/STATUS_ID.md` and `docs/HOOK_COMPATIBILITY_AUDIT.md` for bytecode evidence, hook risks, build blockers, and device test requirements.

## Build prerequisites

- JDK 17 or newer (JDK 21 is available in the current audit environment).
- Android SDK Platform 35 and matching Android build-tools including `aapt2`.
- Gradle 8.9 with Android Gradle Plugin 8.7.3.
- Network access to Google Maven, Maven Central, Gradle Plugin Portal, and Appodeal, the Aliyun public Maven mirror, or upstream `https://api.xposed.info/` for Xposed API 82.
- This archive does not include `gradlew` or the Gradle wrapper JAR. Generate/commit a real wrapper from Gradle 8.9 in a network-enabled Android build environment; do not substitute placeholder scripts.

Build tasks after prerequisites are installed: `gradle :app:verifyXposedApi82Resolution` then `gradle :app:assembleDebug` (or `./gradlew :app:assembleDebug` after a genuine wrapper is added).

A successful Java syntax check, source ZIP, or metadata inspection is not an APK build. The APK must be inspected for package `id.ip26.controlcenter`, LSPosed metadata, `xposed_init`, signature/integrity, then installed only in a controlled test setup. Device testing on the target TECNO LI7 remains mandatory before calling this project functional.


### 0.1.30-dev lifecycle hardening
Animator callbacks now use a terminal-state guard, validate overlay ownership before starting on attach, and mark callbacks terminal on both cancel and normal end. The fake-model regression suite covers View recreation, portrait/landscape remeasurement, late callbacks, vendor background replacement, and repeated Control Center open/close cycles. These are deterministic model tests, not Android framework runtime tests.

## Legacy Xposed API compatibility

This project currently targets the **legacy XposedBridge API 82** (`de.robv.android.xposed.*`) because its entry point implements `IXposedHookLoadPackage` and uses `XposedHelpers`/`XposedBridge`. The dependency is `compileOnly`, so framework API classes must not be bundled into the APK. LSPosed supports legacy Xposed modules, but this is not the newer `io.github.libxposed` API. Do not replace the dependency or entry point with modern API artifacts without porting the hook implementation and packaging metadata together.


## Build gate 0.1.30-dev

Workflow CI explicitly resolves `debugCompileClasspath` (including legacy Xposed API 82) before Java compilation, then checks that `LiquidGlassEntry` is defined in DEX with `apkanalyzer`. This source archive does not prove a remote CI run; APK status remains not built until a real artifact is produced and verified.
