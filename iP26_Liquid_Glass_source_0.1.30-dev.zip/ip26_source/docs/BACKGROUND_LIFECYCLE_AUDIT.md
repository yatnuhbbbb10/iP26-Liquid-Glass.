# Audit background dan lifecycle — 0.1.24-dev

## Perubahan

- Pencarian overlay kini menelusuri `LayerDrawable` bertingkat berdasarkan identitas objek, bukan kesamaan visual. Jika Transsion membungkus background yang sama, overlay iP26 diperbarui dan tidak ditambahkan lagi.
- Jika background vendor memiliki `ConstantState`, salinan dibuat lalu state, level, bounds, visibility, dan alpha runtime disalin sebelum dijadikan lapisan dasar.
- Jika background tidak memiliki `ConstantState`, instance vendor dipertahankan tanpa memanggil `mutate()` secara eksplisit.
- Overlay yang diganti oleh vendor tidak dianggap milik iP26; hook berikutnya dapat memasang overlay baru tanpa mengubah background asing.
- Animasi tetap hanya mengubah alpha drawable overlay. Saat detach, animasi dibatalkan dan overlay yang masih aktif diselesaikan ke alpha penuh.

## Batas verifikasi

Audit ini adalah pemeriksaan source dan kompilasi terhadap stub API lokal. Belum ada observasi runtime saat Control Center dibuka/tutup pada TECNO LI7. Callback `setBackground()` milik vendor yang terjadi setelah hook dan tanpa pemanggilan ulang hook tidak dapat dijamin terdeteksi oleh source saat ini. Pengujian perangkat diperlukan untuk memastikan apakah Transsion mengganti background pada jalur tersebut.

## Matriks pengujian perangkat yang masih diperlukan

1. Buka/tutup Control Center minimal 20 kali; pastikan jumlah layer glass tidak bertambah.
2. Putar layar portrait/landscape dan ulangi buka/tutup.
3. Ubah brightness manual dan otomatis; pastikan nilai dan sentuhan tetap sinkron.
4. Ubah volume dengan slider, tombol fisik, dan panel audio; pastikan stream volume tetap benar.
5. Trigger rekreasi view dan perubahan tema/configuration; pastikan background vendor tetap terlihat.
6. Periksa logcat untuk `iP26:` dan crash SystemUI.

## Regression pass 0.1.24-dev

Static regression checks are now maintained in `tools/audit_source.py`. They verify the hook scope/signatures, fail-closed native vertical predicate, recursive overlay identity detection, vendor background layering, animation alpha target, LSPosed metadata, and that the KernelSU directory remains explicitly documented as a scaffold. These checks inspect source text only; they do not execute Android Drawable/Animator behavior.

### Lifecycle cases to verify on the target ROM

- [ ] Open/close Control Center repeatedly (20 cycles) and confirm one glass layer per slider.
- [ ] Recreate `SeekLayout` while an old slider view is detached; confirm the old overlay is not retained by a running animator.
- [ ] Force vendor `setBackground()` replacement during fade-in and confirm the replacement remains untouched.
- [ ] Re-wrap the existing background in one or more `LayerDrawable` levels and confirm the existing overlay is found by identity.
- [ ] Recreate brightness/volume views and verify no stale geometry listeners or visual alpha remain.
- [ ] Test portrait/landscape and display-size changes; compare runtime dimensions before changing layout params.

No device result is implied by this checklist.
