# Pengujian lifecycle fake-model 0.1.26-dev

`tools/test_lifecycle_model.py` menjalankan 12 skenario deterministik terhadap model Python untuk identitas Drawable, LayerDrawable bertingkat/siklik, callback Animator, pergantian background, View recreation, dan perubahan geometri orientasi. Ini **bukan** Android framework runtime test, Robolectric, LSPosed test, atau pengujian TECNO LI7.

## Skenario
1. Overlay ditemukan di LayerDrawable bertingkat berdasarkan identitas.
2. Background vendor diganti saat fade; background baru tidak dimodifikasi.
3. Detach/cancel menyelesaikan alpha hanya untuk overlay yang masih dimiliki.
4. Graf LayerDrawable siklik tidak menyebabkan traversal tanpa akhir.
5. Animator lama tidak dapat memodifikasi overlay baru.
6. Recomposition nested vendor mempertahankan identitas overlay.
7. Callback update terlambat setelah cancel diabaikan walau overlay masih terpasang.
8. View yang detached dengan background pengganti tidak memulai animator ketika attach.
9. View recreation membuat kepemilikan overlay independen.
10. Perubahan portrait/landscape memperbarui geometri tanpa styling memaksa ukuran.
11. Siklus buka/tutup berulang tidak menumpuk overlay yang sama.
12. Callback setelah animation end normal tidak mengubah alpha.

Jalankan: `python3 tools/test_lifecycle_model.py`. Hasil lulus hanya membuktikan model simulasi sesuai assertion; validasi framework Android dan perangkat tetap wajib.
