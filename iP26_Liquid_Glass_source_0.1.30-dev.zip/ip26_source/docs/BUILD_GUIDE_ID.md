# Panduan build Android

## Lokal (Android Studio / terminal)
- JDK 17 atau lebih baru (JDK 21 juga dapat digunakan).
- Android Gradle Plugin 8.7.3 dan Gradle 8.9.
- Android SDK Platform 35 dan Build Tools 35.0.0.
- Pastikan akses ke Google Maven, Maven Central, dan salah satu sumber Xposed API 82: repository Appodeal (`https://artifactory.appodeal.com/appodeal-public/`), mirror Maven publik Aliyun (`https://maven.aliyun.com/repository/public/`), atau upstream (`https://api.xposed.info/`).
- Dari root proyek: `gradle --version`, `python3 tools/test_lifecycle_model.py`, `python3 tools/audit_source.py`, lalu `gradle :app:verifyXposedApi82Resolution` dan `gradle :app:assembleDebug`.
- Verifikasi APK: `test -s app/build/outputs/apk/debug/app-debug.apk`; kemudian gunakan `aapt dump badging`, `apkanalyzer manifest application-id`, `apkanalyzer dex packages --defined-only`, `apkanalyzer manifest print`, dan `apksigner verify --verbose --print-certs`.

## CI
Workflow `.github/workflows/android-build.yml` menyiapkan JDK 17, Gradle 8.9, Android SDK 35, menjalankan tes model dan audit statis, lalu menjalankan `assembleDebug`. APK hanya diunggah sebagai artifact jika file benar-benar tercipta. Workflow belum dijalankan dari lingkungan ini.

Tidak ada Gradle Wrapper JAR palsu yang ditambahkan.


## Menjalankan workflow GitHub Actions
1. Buat repository GitHub dan unggah seluruh isi folder source ini ke branch `main` atau `master`.
2. Pastikan workflow `.github/workflows/android-build.yml` ikut terunggah.
3. Buka tab **Actions**, pilih **Android APK build**, lalu tekan **Run workflow** (atau push commit ke branch yang dipantau).
4. Tunggu seluruh langkah selesai. Jika `Build debug APK` dan `Verify APK artifact` berstatus sukses, unduh artifact `ip26-liquid-glass-debug-apk` dari ringkasan run.
5. Jika gagal, buka log langkah yang gagal dan unduh artifact diagnostik bila tersedia. Task `:app:verifyXposedApi82Resolution` kini memaksa Gradle mengunduh file `api-82.jar` melalui artifact view, memeriksa koordinat modul dan ukuran file; sekadar melihat komponen pada dependency graph tidak dianggap bukti unduhan sukses. Coba sumber repository Appodeal, mirror Aliyun, atau upstream Xposed sesuai log kegagalan jaringan.

Workflow ini baru berupa konfigurasi source. Tidak ada bukti run GitHub Actions dari project ini, sehingga belum ada APK yang dapat diunduh. Android Studio dapat membuka proyek dengan Gradle 8.9 terpasang/terpilih; wrapper belum disertakan karena wrapper JAR asli tidak tersedia untuk dibuat secara offline.

## Verifikasi APK otomatis (0.1.30-dev)

Setelah `assembleDebug`, jalankan `tools/verify_apk.sh app/build/outputs/apk/debug/app-debug.apk`. Skrip memeriksa struktur ZIP/CRC, `classes.dex`, `assets/xposed_init`, applicationId, metadata Xposed API 82, dan tanda tangan APK debug. Pemeriksaan ini adalah validasi artefak build, bukan bukti bahwa hook berhasil di LSPosed atau pada TECNO LI7.

Build memakai Java source/target 17 secara eksplisit. AGP 8.7.3 cocok dengan Gradle 8.9 dan mendukung API 35; jangan menaikkan AGP ke 8.9 tanpa menaikkan Gradle ke versi minimum yang lebih baru. CI kini menjalankan task kompilasi Java terhadap dependency API 82 (sehingga resolusi dependency benar-benar diperlukan), build, verifikasi APK, lalu baru mengunggah artifact. Pull request juga memicu workflow. CI tetap harus dijalankan oleh pemilik repository; arsip source ini sendiri tidak menjalankan GitHub Actions.

### API Xposed yang digunakan

Source menggunakan API Xposed legacy level 82: `IXposedHookLoadPackage`, `XC_MethodHook`, `XC_MethodReplacement`, `XposedBridge`, dan `XposedHelpers`. Dependency `de.robv.android.xposed:api:82` harus tetap `compileOnly`; jangan mengubahnya menjadi `implementation` karena kelas framework tidak boleh dibundel ke APK. LSPosed modern juga menyediakan API `io.github.libxposed`, tetapi API tersebut memakai entry point, metadata, dan model hook yang berbeda. Porting ke API modern bukan penggantian satu baris dependency.


## Pemeriksaan dependency dan DEX (0.1.30-dev)

CI menjalankan `dependencyInsight` untuk melaporkan jalur dependency dan `:app:verifyXposedApi82Resolution` untuk memaksa unduhan JAR API 82 sebagai gate sebelum kompilasi. Setelah APK dibuat, pemeriksa juga memastikan class `id.ip26.controlcenter.LiquidGlassEntry` benar-benar terdefinisi dalam DEX menggunakan `apkanalyzer dex packages --defined-only`, bukan sekadar memeriksa bahwa file `classes.dex` ada.

Catatan: ketersediaan repository Xposed tetap harus dibuktikan oleh run CI. Lingkungan pengembangan ini tidak dapat mengakses DNS/internet untuk mengunduh dependency, Gradle, atau Android SDK.

Android SDK setup CI menggunakan `android-actions/setup-android@v4`. Skrip verifikasi mencari `apkanalyzer` di direktori cmdline-tools bernomor maupun alias `latest`, karena lokasi instalasi dapat berbeda antar runner.


## Perubahan audit build 0.1.30-dev

- Repository resolusi API 82 kini mencoba Appodeal (repository yang tercantum untuk POM/JAR API 82), lalu mirror Maven publik Aliyun, dan upstream `api.xposed.info` sebagai fallback. Konektivitas ketiganya belum dapat diuji dari container kerja ini karena DNS eksternal tidak tersedia.
- Task `:app:verifyXposedApi82Resolution` memaksa resolusi artifact view `debugCompileClasspath`, memeriksa modul `de.robv.android.xposed:api:82`, nama `api-82.jar`, dan file nonkosong; build gagal bila JAR tidak terunduh. Ini menutup celah bahwa task `dependencies` dapat menampilkan `FAILED` tanpa selalu menggagalkan report task.
- GitHub Actions mengunggah laporan build ketika gagal dan hanya mengunggah APK setelah `aapt`, `apkanalyzer`, pemeriksaan metadata/DEX, dan `apksigner verify` lulus.
- Build lokal/CI aktual tetap belum dijalankan pada revisi ini; konfigurasi yang lebih ketat bukan bukti bahwa artifact sudah berhasil dibuat.
