# Audit race condition background/animasi — 0.1.24-dev

## Temuan dan perubahan

- Penelusuran `LayerDrawable` sebelumnya menggunakan rekursi tanpa himpunan `visited`. Graph drawable vendor normalnya berbentuk pohon, tetapi wrapper yang saling mereferensikan dapat menyebabkan rekursi tak berujung pada thread UI.
- `containsDrawableIdentity()` kini menggunakan `IdentityHashMap`-backed set. Setiap objek hanya diperiksa sekali, sehingga pencarian berhenti aman pada graph yang memiliki siklus. Perbandingan tetap berdasarkan identitas (`==`), bukan `equals()`.
- Animator memeriksa apakah overlay masih terpasang sebelum mengubah alpha. Jika background vendor diganti saat fade berlangsung, update berikutnya membatalkan animator; callback cancel hanya menyelesaikan alpha jika overlay lama masih menjadi bagian background aktif.
- Jika view dilepas saat fade berlangsung, animator dibatalkan dan overlay yang masih aktif diselesaikan ke alpha 255. Background vendor pengganti tidak disentuh.

## Batasan race

Operasi background dan animator umumnya berjalan pada main thread Android, sehingga pemeriksaan dan perubahan dalam satu callback tidak disela callback UI lain. Source ini tidak mengamati mutasi drawable internal yang dilakukan vendor tanpa mengganti root background. Tidak ada klaim bahwa semua race runtime telah terbukti tertutup tanpa pengujian pada ROM target.

## Matriks uji regresi

1. Replace background sebelum frame animator pertama.
2. Replace background di tengah fade (sekitar alpha 1-254).
3. Detach/re-attach view selama fade.
4. Re-wrap background dalam beberapa `LayerDrawable` bertingkat.
5. Ulangi callback styling 20 kali dan hitung layer overlay berdasarkan identitas.
6. Uji graph drawable berulang/siklik pada fake drawable harness jika API test Android tersedia.
7. Pastikan callback cancel tidak mengubah background vendor baru.

Semua skenario di atas masih memerlukan Android instrumentation/fake drawable runtime. Pemeriksaan source statis bukan bukti uji Android.
