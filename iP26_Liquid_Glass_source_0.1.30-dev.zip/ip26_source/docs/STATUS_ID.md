# Status source iP26 Liquid Glass — 0.1.30-dev

## Fokus revisi ini: kesiapan build APK nyata
- Repository API 82 disusun dengan repository Appodeal, mirror Maven publik Aliyun, lalu upstream `api.xposed.info` untuk group `de.robv.android.xposed`. Konektivitas dan keberadaan artifact belum dapat diverifikasi dari lingkungan ini.
- Ditambahkan task Gradle `:app:verifyXposedApi82Resolution` yang memaksa unduhan JAR `api-82.jar` dari artifact view `debugCompileClasspath`, lalu memeriksa koordinat modul dan ukuran file sebelum kompilasi.
- Workflow GitHub Actions kini menjalankan `dependencyInsight`, pemeriksaan unduhan JAR API 82 yang wajib lulus, kompilasi Java, `assembleDebug`, verifikasi APK, dan unggah diagnostik jika gagal.
- `aapt`, `apkanalyzer`, dan `apksigner` tetap digunakan oleh `tools/verify_apk.sh`; APK hanya diunggah setelah seluruh pemeriksaan lolos.

## Batas verifikasi saat ini
- Container ini memiliki Java 21 tetapi tidak memiliki Gradle, Android SDK, `aapt`, `apkanalyzer`, `apksigner`, atau `adb`.
- DNS eksternal gagal untuk `api.xposed.info`, `maven.aliyun.com`, dan `artifactory.appodeal.com`; belum ada satu pun endpoint yang dapat diuji langsung dari container.
- Karena itu dependency API 82 belum berhasil diunduh, `assembleDebug` belum berjalan, tidak ada APK nyata yang dihasilkan, dan verifikasi APK Android belum terjadi.
- Folder `kernelsu-module/` masih scaffold pendamping inert, bukan modul KernelSU siap flash.
- Tidak ada pengujian runtime pada TECNO LI7 dalam revisi ini.

## Jalur build yang dapat dijalankan
1. Unggah seluruh isi source ke repository GitHub (termasuk folder tersembunyi `.github/workflows`).
2. Jalankan Actions > Android APK build > Run workflow.
3. Pastikan langkah `Download and require the actual Xposed API 82 JAR`, `Build debug APK`, dan `Verify APK contents, metadata, and signature` sukses.
4. Jika resolusi API gagal, gunakan artifact diagnostik/log untuk memastikan apakah repository Appodeal, mirror Aliyun, atau upstream Xposed yang gagal. Jangan mengunduh JAR dari mirror tak dikenal dan memasukkannya ke APK.
5. APK artifact hanya dianggap nyata bila workflow berhasil mengunggah `ip26-liquid-glass-debug-apk`; tanda tangan debug CI bukan tanda tangan rilis pribadi.
