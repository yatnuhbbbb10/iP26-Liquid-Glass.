# Hook compatibility audit — iP26 Liquid Glass 0.1.17-dev

Target analyzed: the Library `TranSystemUI.apk` associated with TECNO LI7 / Android 15 / HiOS 15.1.2.170.

## Native vertical predicate

| Item | Observed in inspected APK | Source behavior |
|---|---|---|
| Owner | `kotlin.io.CloseableKt` | Resolve through the SystemUI classloader |
| Method | `isQSCenterSupport()` | Hook only the no-argument method |
| DEX descriptor | `()Z` | Require primitive `boolean` return |
| Access flags | `0x9` (`public static`) | Require `static` before hooking |
| Known consumers | Four `QcToggleSeekBar` call sites in the inspected build: draw, measure, size-change, touch | Return `true` to activate the vendor's own vertical path |

The vendor path performs its own Canvas transform, measurement/size handling, and touch-coordinate mapping. Do not rotate `QcToggleSeekBar` or its parent independently; that could double-transform drawing and touch.

The 0.1.17-dev preflight is fail-closed: class/method lookup or signature mismatch is logged and the vendor default is retained. A successful preflight only proves the reflected method shape, not that the resulting layout is correct or stable on-device.

## Remaining risks

1. The method is replaced for every caller in the relevant classloader, not only calls originating from `QcToggleSeekBar`. The inspected APK's known references are narrow, but a future vendor update may add consumers.
2. Classloader resolution and Xposed hook installation must be confirmed on the exact firmware. A different Kotlin stdlib packaging arrangement may cause lookup failure.
3. Vendor class/method names for `SeekLayout`, brightness slider and volume slider may change in an OTA.
4. `onFinishInflate()` can run during view recreation. Repeated styling is designed to avoid stacking the module's own overlay, but must still be observed during repeated Control Center open/close cycles.
5. Brightness and volume functionality is preserved by retaining vendor widgets; functional touch, physical-key, automatic-brightness, stream-volume and lifecycle tests have not been performed.
6. Glass is a translucent overlay, not a sampled/backdrop blur.

## Required target-device test sequence

- Confirm LSPosed loads the entry point only for `com.android.systemui`.
- Check logs for predicate owner/classloader verification and successful hook installation.
- Open/close Control Center repeatedly; rotate portrait/landscape; check for duplicate overlays and layout drift.
- Drag brightness at low/mid/high positions and verify the system brightness value changes correctly.
- Drag volume and test media/ringtone/alarm streams as applicable; verify hardware volume keys still work.
- Test slider recreation, notification shade expansion/collapse, display-size/font-scale changes, and SystemUI process restart.
- Watch for SystemUI crashes, ANRs, clipped thumb/track, inaccessible touch regions, and unexpected callers affected by the global predicate.
- Disable the LSPosed module via safe mode if SystemUI becomes unstable. Do not replace the signed vendor SystemUI APK.

## Build state

This source archive is not an APK. It has no Gradle wrapper. The build requires JDK, Gradle 8.9, AGP 8.7.3, Android SDK Platform 35/build-tools, Maven access, and Xposed API 82. No APK compilation or device validation is claimed.


## Lifecycle hardening — 0.1.18-dev (historical)

- `SeekLayout` is resolved before hooking. Preflight requires it to extend `ViewGroup` and to declare the exact instance method `void setCentralSurfaces(CentralSurfaces)`; mismatch is logged and vendor behavior is retained.
- Brightness and volume slider hooks require each vendor class to extend `View` and declare its own no-argument, instance `void onFinishInflate()`. This avoids accidentally hooking an inherited base `View` lifecycle method globally.
- UI-thread posting and styling callbacks are guarded with error handling and diagnostic logs.
- Repeated styling remains idempotent by checking the exact overlay drawable identity; the original vendor background remains beneath the overlay.
- These are static compatibility guards only. Exact declarations and hook behavior still require verification on the target SystemUI classloader and device.

## Audit layout kartu dan build 0.1.22-dev

- Kartu brightness dan volume tetap memakai instance vendor asli. Overlay visual sekarang dibedakan secara halus: brightness memakai glass netral terang, volume memakai tint biru-es; tidak mengubah progress, listener, controller, track/thumb internal, atau event sentuh.
- Overlay diperbarui berdasarkan identitas drawable yang disimpan untuk menghindari penumpukan ketika `onFinishInflate()` dan `setCentralSurfaces()` sama-sama memicu styling.
- Ini masih translucent gradient + stroke + elevation, bukan backdrop blur sejati. Blur tidak ditambahkan karena blur konten View sendiri bukan backdrop blur dan berisiko mengaburkan slider.
- Lifecycle open/close, reinflation, orientasi, brightness otomatis, volume stream, tombol fisik, dan stabilitas SystemUI belum dapat diuji tanpa perangkat.
- Gradle 8.9 / AGP 8.7.3 / SDK 35 / Xposed API 82 dicatat dalam `BUILD_GUIDE_ID.md`. Wrapper tidak ditambahkan karena wrapper JAR/distribusi Gradle tidak tersedia untuk verifikasi.

## Audit API LSPosed legacy 82 — 0.1.27-dev

- Entry point `LiquidGlassEntry` mengimplementasikan `IXposedHookLoadPackage` dan memakai keluarga `de.robv.android.xposed.*`; ini konsisten dengan dependency legacy `de.robv.android.xposed:api:82`.
- Dependency disetel `compileOnly`. API hook harus disediakan framework saat runtime dan tidak boleh dipaketkan sebagai kelas milik modul.
- Manifest lama memuat `xposedmodule=true`, deskripsi, dan `xposedminversion=82`; `assets/xposed_init` menunjuk nama kelas yang sama dengan entry point.
- `xposedminversion=82` adalah level API Xposed legacy, bukan nomor versi Android dan bukan klaim versi rilis LSPosed. LSPosed modern memiliki `io.github.libxposed` dengan `META-INF/xposed/java_init.list`, metadata/module.prop, dan model hook yang berbeda. Source ini belum dipindahkan ke API modern.
- Build CI sekarang mengompilasi source terhadap API 82 (memaksa resolusi dependency) dan menjalankan pemeriksa APK yang memvalidasi package, metadata, entry point, DEX, CRC ZIP, serta signature. Pemeriksaan itu baru dapat memberi hasil setelah workflow benar-benar berjalan.
- Resolusi `api:82` merupakan titik rawan jaringan/repository; Appodeal tercantum sebagai host POM/JAR pada indeks Maven, dengan Aliyun dan upstream sebagai fallback. Jika CI gagal di tahap dependency, ambil pesan Gradle lengkap sebelum mengganti repository atau versi. Jangan mengunduh JAR dari mirror tak tepercaya atau membundel API ke APK.


## Dependency build gate — 0.1.30-dev

Dependency `de.robv.android.xposed:api:82` tetap `compileOnly`; repository Appodeal dicoba lebih dulu, diikuti Aliyun public Maven dan upstream `api.xposed.info`. Workflow menjalankan `dependencyInsight` dan task `:app:verifyXposedApi82Resolution` yang memaksa unduhan `api-82.jar`, lalu gagal bila file artefak tidak tersedia atau kosong. Hasil run CI tetap diperlukan untuk membuktikan ketersediaan artifact dan seluruh pemanggilan API lolos kompilasi. Pemeriksaan source statis tidak dapat membuktikan resolusi artifact atau kompatibilitas biner.
