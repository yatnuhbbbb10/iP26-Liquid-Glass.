#!/usr/bin/env python3
"""Deterministic fake-model regression tests; NOT Android/Robolectric tests."""
from dataclasses import dataclass, field


@dataclass(eq=False)
class Drawable:
    alpha: int = 255


@dataclass(eq=False)
class Layer(Drawable):
    children: list = field(default_factory=list)


def contains(root, target):
    seen = set()
    def visit(node):
        if node is None or id(node) in seen:
            return False
        if node is target:
            return True
        seen.add(id(node))
        return isinstance(node, Layer) and any(visit(child) for child in node.children)
    return visit(root)


@dataclass(eq=False)
class FakeView:
    background: Drawable | None
    overlay: Drawable | None = None
    attached: bool = False
    orientation: str = 'portrait'
    measured_size: tuple = (0, 0)
    listener_installed: bool = False

    def current(self, target):
        return self.overlay is target and contains(self.background, target)

    def apply_overlay(self, overlay):
        if self.current(overlay):
            return
        base = self.background
        self.overlay = overlay
        self.background = Layer(children=[base, overlay]) if base is not None else overlay


class FakeAnimator:
    """Model terminal callback guard and identity validation in the Java hook."""
    def __init__(self, view, overlay):
        self.view, self.overlay = view, overlay
        self.cancelled = False
        self.ended = False
        self.started = False
        self.terminal = False

    def start(self):
        if self.terminal or not self.view.current(self.overlay):
            self.terminal = True
            return
        self.started = True

    def frame(self, alpha):
        if self.terminal:
            return
        if not self.view.current(self.overlay):
            self.terminal = True
            self.cancel()
            return
        self.overlay.alpha = alpha

    def cancel(self):
        self.cancelled = True
        self.terminal = True
        if self.view.current(self.overlay):
            self.overlay.alpha = 255

    def end(self):
        self.ended = True
        self.terminal = True


def test_nested_overlay_reused_by_identity():
    base, glass = Drawable(), Drawable(0)
    v = FakeView(Layer(children=[Layer(children=[base, glass])]), glass)
    assert v.current(glass) and contains(v.background, glass)


def test_vendor_root_replacement_during_fade_is_not_mutated():
    glass, vendor = Drawable(70), Drawable(255)
    v = FakeView(Layer(children=[Drawable(), glass]), glass)
    a = FakeAnimator(v, glass)
    v.background = vendor
    a.frame(120)
    assert a.cancelled and vendor.alpha == 255 and glass.alpha == 70


def test_detach_cancel_settles_only_owned_overlay():
    glass = Drawable(84)
    v = FakeView(Layer(children=[Drawable(), glass]), glass, attached=True)
    a = FakeAnimator(v, glass)
    v.attached = False
    a.cancel()
    assert glass.alpha == 255


def test_cyclic_layer_graph_terminates():
    glass, outer, inner = Drawable(), Layer(), Layer()
    outer.children = [inner]
    inner.children = [outer, glass]
    v = FakeView(outer, glass)
    assert v.current(glass)


def test_stale_animator_cannot_mutate_new_overlay():
    old, new = Drawable(40), Drawable(255)
    v = FakeView(Layer(children=[Drawable(), old]), old)
    a = FakeAnimator(v, old)
    v.overlay = new
    v.background = Layer(children=[Drawable(), new])
    a.frame(180)
    assert a.cancelled and old.alpha == 40 and new.alpha == 255


def test_vendor_nested_recomposition_preserves_same_overlay():
    glass = Drawable(100)
    vendor_rewrapped = Layer(children=[Layer(children=[Drawable(), glass])])
    v = FakeView(vendor_rewrapped, glass)
    previous = v.overlay
    assert v.current(glass) and previous is glass


def test_late_update_after_cancel_is_ignored_even_if_overlay_still_current():
    glass = Drawable(255)
    v = FakeView(Layer(children=[glass]), glass)
    a = FakeAnimator(v, glass)
    a.cancel()
    a.frame(22)
    assert glass.alpha == 255 and a.terminal


def test_detached_view_with_replaced_background_does_not_start_on_attach():
    glass, vendor = Drawable(0), Drawable(255)
    v = FakeView(Layer(children=[glass]), glass, attached=False)
    a = FakeAnimator(v, glass)
    v.background = vendor
    v.attached = True
    a.start()
    assert not a.started and a.terminal and vendor.alpha == 255


def test_view_recreation_has_independent_overlay_ownership():
    old_glass, new_glass = Drawable(255), Drawable(0)
    old = FakeView(Layer(children=[Drawable(), old_glass]), old_glass)
    new = FakeView(Drawable(), None)
    new.apply_overlay(new_glass)
    assert old.current(old_glass) and new.current(new_glass)
    assert old.overlay is not new.overlay


def test_portrait_landscape_remeasure_does_not_rotate_or_rewrite_geometry():
    glass = Drawable(255)
    v = FakeView(Layer(children=[glass]), glass, orientation='portrait', measured_size=(300, 150))
    before = v.measured_size
    v.orientation = 'landscape'
    v.measured_size = (500, 120)  # Android's layout pass supplies the new geometry.
    assert v.orientation == 'landscape' and v.measured_size != before
    assert v.current(glass)  # Styling does not own or force these dimensions.


def test_repeated_control_center_open_close_does_not_stack_same_overlay():
    glass, base = Drawable(255), Drawable()
    v = FakeView(Layer(children=[base, glass]), glass)
    for _ in range(20):
        assert v.current(glass)
        v.apply_overlay(glass)
    def count(node, target, seen=None):
        seen = set() if seen is None else seen
        if node is None or id(node) in seen:
            return 0
        seen.add(id(node))
        if node is target:
            return 1
        return sum(count(x, target, seen) for x in node.children) if isinstance(node, Layer) else 0
    assert count(v.background, glass) == 1


def test_normal_animation_end_blocks_subsequent_frames():
    glass = Drawable(255)
    v = FakeView(Layer(children=[glass]), glass)
    a = FakeAnimator(v, glass)
    a.start()
    a.end()
    a.frame(12)
    assert a.ended and glass.alpha == 255


if __name__ == '__main__':
    tests = [value for name, value in sorted(globals().items())
             if name.startswith('test_') and callable(value)]
    for test in tests:
        test()
        print('PASS', test.__name__)
    print(f'RESULT: {len(tests)}/{len(tests)} fake-model lifecycle tests passed')
