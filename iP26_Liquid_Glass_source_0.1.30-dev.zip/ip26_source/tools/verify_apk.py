#!/usr/bin/env python3
"""Structural APK checks; signature and manifest decoding are checked by CI shell steps."""
import sys
import zipfile
from pathlib import Path

EXPECTED_ENTRY = b"id.ip26.controlcenter.LiquidGlassEntry"

def fail(message: str) -> None:
    print(f"FAIL: {message}")
    raise SystemExit(1)

if len(sys.argv) != 2:
    fail("usage: python3 tools/verify_apk.py path/to/app-debug.apk")
apk = Path(sys.argv[1])
if not apk.is_file() or apk.stat().st_size == 0:
    fail(f"APK missing or empty: {apk}")
try:
    with zipfile.ZipFile(apk) as archive:
        bad = archive.testzip()
        if bad:
            fail(f"ZIP CRC failure in {bad}")
        names = set(archive.namelist())
        if "AndroidManifest.xml" not in names:
            fail("AndroidManifest.xml missing")
        if "classes.dex" not in names and not any(n.startswith("classes") and n.endswith(".dex") for n in names):
            fail("DEX bytecode missing")
        if "assets/xposed_init" not in names:
            fail("legacy Xposed entry-point asset missing")
        entry = archive.read("assets/xposed_init").strip()
        if entry != EXPECTED_ENTRY:
            fail(f"unexpected Xposed entry point: {entry!r}")
except zipfile.BadZipFile:
    fail("output is not a valid APK/ZIP archive")
print(f"PASS: APK archive structure and CRC ({apk.stat().st_size} bytes)")
print("PASS: AndroidManifest.xml and DEX payload present")
print("PASS: assets/xposed_init points to LiquidGlassEntry")
