#!/usr/bin/env bash
set -euo pipefail
APK="${1:-app/build/outputs/apk/debug/app-debug.apk}"
SDK_ROOT="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-}}"
AAPT="${AAPT:-$(command -v aapt || true)}"
APKSIGNER="${APKSIGNER:-$(command -v apksigner || true)}"
APKANALYZER="${APKANALYZER:-$(command -v apkanalyzer || true)}"
if [[ -n "$SDK_ROOT" ]]; then
  [[ -n "$AAPT" ]] || AAPT="$SDK_ROOT/build-tools/35.0.0/aapt"
  [[ -n "$APKSIGNER" ]] || APKSIGNER="$SDK_ROOT/build-tools/35.0.0/apksigner"
  if [[ -z "$APKANALYZER" ]]; then
    # setup-android may install a numbered cmdline-tools directory (for example
    # 16.0) rather than a `latest` alias. Select the highest available version.
    APKANALYZER="$(find "$SDK_ROOT/cmdline-tools" -type f -name apkanalyzer 2>/dev/null | sort -V | tail -n 1 || true)"
  fi
fi

python3 tools/verify_apk.py "$APK"
[[ -n "$AAPT" ]] || { echo "aapt not found" >&2; exit 2; }
[[ -n "$APKSIGNER" ]] || { echo "apksigner not found" >&2; exit 2; }
[[ -n "$APKANALYZER" ]] || { echo "apkanalyzer not found" >&2; exit 2; }

BADGING="$($AAPT dump badging "$APK")"
grep -F "package: name='id.ip26.controlcenter'" <<<"$BADGING" >/dev/null || {
  echo "Unexpected applicationId" >&2; exit 1;
}
APP_ID="$($APKANALYZER manifest application-id "$APK")"
[[ "$APP_ID" == "id.ip26.controlcenter" ]] || {
  echo "apkanalyzer reports unexpected applicationId: $APP_ID" >&2; exit 1;
}
DEX_TREE="$($APKANALYZER dex packages --defined-only "$APK")"
grep -F 'id.ip26.controlcenter.LiquidGlassEntry' <<<"$DEX_TREE" >/dev/null || {
  echo "LiquidGlassEntry class missing from DEX" >&2; exit 1;
}
MANIFEST="$($APKANALYZER manifest print "$APK")"
grep -F 'android:name="xposedmodule"' <<<"$MANIFEST" >/dev/null || {
  echo "xposedmodule metadata missing" >&2; exit 1;
}
grep -F 'android:name="xposedminversion"' <<<"$MANIFEST" >/dev/null || {
  echo "xposedminversion metadata missing" >&2; exit 1;
}
grep -F 'android:value="82"' <<<"$MANIFEST" >/dev/null || {
  echo "expected legacy Xposed API level 82 metadata missing" >&2; exit 1;
}
"$APKSIGNER" verify --verbose "$APK"
echo "PASS: applicationId, DEX entry class, LSPosed legacy metadata, and APK signature verified"
