#!/usr/bin/env python3
"""Unit tests for ZIP/entry-point checks using synthetic archives, not real APKs."""
import subprocess
import tempfile
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
VERIFIER = ROOT / "tools/verify_apk.py"
ENTRY = b"id.ip26.controlcenter.LiquidGlassEntry\n"

def make_archive(path: Path, entry: bytes = ENTRY, dex: bool = True) -> None:
    with zipfile.ZipFile(path, "w") as archive:
        archive.writestr("AndroidManifest.xml", b"synthetic-manifest")
        if dex:
            archive.writestr("classes.dex", b"dex\nsynthetic")
        archive.writestr("assets/xposed_init", entry)

def run(path: Path) -> subprocess.CompletedProcess:
    return subprocess.run(["python3", str(VERIFIER), str(path)], text=True, capture_output=True)

def test_valid_structure_passes():
    with tempfile.TemporaryDirectory() as tmp:
        apk = Path(tmp) / "synthetic.apk"
        make_archive(apk)
        result = run(apk)
        assert result.returncode == 0, result.stdout + result.stderr

def test_wrong_entry_point_fails():
    with tempfile.TemporaryDirectory() as tmp:
        apk = Path(tmp) / "wrong.apk"
        make_archive(apk, b"example.WrongEntry\n")
        result = run(apk)
        assert result.returncode != 0 and "unexpected Xposed entry point" in result.stdout

def test_missing_dex_fails():
    with tempfile.TemporaryDirectory() as tmp:
        apk = Path(tmp) / "no-dex.apk"
        make_archive(apk, dex=False)
        result = run(apk)
        assert result.returncode != 0 and "DEX bytecode missing" in result.stdout

if __name__ == "__main__":
    tests = [test_valid_structure_passes, test_wrong_entry_point_fails, test_missing_dex_fails]
    for test in tests:
        test()
        print(f"PASS {test.__name__}")
    print(f"RESULT: {len(tests)}/{len(tests)} APK-verifier unit tests passed (synthetic archives only)")
