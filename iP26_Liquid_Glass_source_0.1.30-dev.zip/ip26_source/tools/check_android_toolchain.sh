#!/usr/bin/env sh
set -u
echo "== Java =="
command -v java || true
java -version 2>&1 | head -n 3 || true
echo "== Build commands =="
for c in gradle sdkmanager aapt2 d8 apksigner adb; do if command -v "$c" >/dev/null 2>&1; then printf '%s: %s\n' "$c" "$(command -v "$c")"; else printf '%s: MISSING\n' "$c"; fi; done
echo "== SDK environment =="
printf 'ANDROID_HOME=%s\n' "${ANDROID_HOME:-unset}"
printf 'ANDROID_SDK_ROOT=%s\n' "${ANDROID_SDK_ROOT:-unset}"
for p in "${ANDROID_HOME:-/nonexistent}" "${ANDROID_SDK_ROOT:-/nonexistent}" /opt/android-sdk /usr/lib/android-sdk "$HOME/Android/Sdk"; do [ ! -d "$p" ] || echo "SDK directory: $p"; done
echo "== Wrapper/cache =="
[ ! -f gradlew ] || echo "gradlew present"
[ ! -d "$HOME/.gradle" ] || echo "Gradle cache present"
echo "This script only inspects local availability; it does not build an APK."
