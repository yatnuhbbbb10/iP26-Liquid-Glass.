#!/usr/bin/env python3
"""Static regression checks for the iP26 LSPosed source (not an Android build)."""
from pathlib import Path
import re
import sys

root = Path(__file__).resolve().parents[1]
java = (root / 'app/src/main/java/id/ip26/controlcenter/LiquidGlassEntry.java').read_text()
gradle = (root / 'app/build.gradle').read_text()
root_gradle = (root / 'build.gradle').read_text()
manifest = (root / 'app/src/main/AndroidManifest.xml').read_text()
entry = (root / 'app/src/main/assets/xposed_init').read_text().strip()
module = (root / 'kernelsu-module/module.prop').read_text()
checks = {
    'brightness hook is scoped to vendor class': 'com.transsion.systemui.widget.TrBrightnessSliderView' in java,
    'volume hook is scoped to vendor class': 'com.transsion.systemui.widget.VolumeSliderView' in java,
    'SeekLayout hook validates ViewGroup and exact instance method': 'ViewGroup.class.isAssignableFrom(seekClass)' in java and 'getDeclaredMethod(\n                    "setCentralSurfaces", centralSurfacesClass)' in java,
    'native vertical predicate fails closed': 'Modifier.isStatic(predicate.getModifiers())' in java and 'predicate.getReturnType() != boolean.class' in java,
    'overlay deduplication uses drawable identity recursively': 'containsDrawableIdentity(current, previousOverlay)' in java and 'containsDrawableIdentity(layers.getDrawable(i), target, visited)' in java,
    'nested drawable traversal is cycle-safe': 'Collections.newSetFromMap(' in java and 'IdentityHashMap<Drawable, Boolean>' in java and '!visited.add(root)' in java,
    'animation checks overlay before alpha mutation': java.index('if (!isGlassOverlayCurrent(view, overlay))') < java.index('overlay.setAlpha((Integer) value.getAnimatedValue())'),
    'cancel callback guards vendor replacement': 'if (isGlassOverlayCurrent(view, overlay)) {\n                    overlay.setAlpha(255);' in java,
    'animator update has terminal callback guard': 'if (terminal[0]) return;' in java and 'terminal[0] = true;\n                value.cancel();' in java,
    'attach callback validates overlay before starting': 'if (!isGlassOverlayCurrent(view, overlay)) {\n                            terminal[0] = true;' in java,
    'normal animation end marks callbacks terminal': 'onAnimationEnd(Animator animation) {\n                terminal[0] = true;' in java,
    'cancel animation marks callbacks terminal': 'onAnimationCancel(Animator animation) {\n                terminal[0] = true;' in java,
    'vendor background is retained under glass': 'new LayerDrawable(new Drawable[]{original, glass})' in java,
    'animation only mutates overlay alpha': 'overlay.setAlpha((Integer) value.getAnimatedValue())' in java,
    'cancel settles only current overlay': 'if (isGlassOverlayCurrent(view, overlay))' in java,
    'no View rotation or touch interception added': 'setRotation(' not in java and 'setOnTouchListener(' not in java,
    'LSPosed entry point matches class': entry == 'id.ip26.controlcenter.LiquidGlassEntry',
    'manifest declares LSPosed module and API 82': 'android:name="xposedmodule" android:value="true"' in manifest and 'android:name="xposedminversion" android:value="82"' in manifest,
    'application id and namespace match': "namespace 'id.ip26.controlcenter'" in gradle and "applicationId 'id.ip26.controlcenter'" in gradle,
    'AGP pinned to 8.7.3': "version '8.7.3'" in root_gradle,
    'app and scaffold version metadata aligned': "versionCode 27" in gradle and "versionName '0.1.30-dev'" in gradle and 'version=0.1.30-dev' in module and 'versionCode=27' in module,
    'CI workflow uses Gradle 8.9 and SDK 35': "gradle-version: '8.9'" in (root / '.github/workflows/android-build.yml').read_text() and "platforms;android-35" in (root / '.github/workflows/android-build.yml').read_text(),
    'Java source and target compatibility are explicit': 'sourceCompatibility JavaVersion.VERSION_17' in gradle and 'targetCompatibility JavaVersion.VERSION_17' in gradle,
    'APK verifier checks entry point and package': (root / 'tools/verify_apk.py').exists() and 'assets/xposed_init' in (root / 'tools/verify_apk.py').read_text() and 'id.ip26.controlcenter.LiquidGlassEntry' in (root / 'tools/verify_apk.py').read_text(),
    'APK verifier checks manifest and signature': 'xposedminversion' in (root / 'tools/verify_apk.sh').read_text() and 'verify --verbose' in (root / 'tools/verify_apk.sh').read_text(),
    'APK verifier confirms entry class exists in DEX': 'dex packages --defined-only' in (root / 'tools/verify_apk.sh').read_text() and 'LiquidGlassEntry' in (root / 'tools/verify_apk.sh').read_text(),
    'CI inspects dependency path and requires actual Xposed API 82 JAR before compilation': 'dependencyInsight --dependency de.robv.android.xposed:api' in (root / '.github/workflows/android-build.yml').read_text() and ':app:verifyXposedApi82Resolution' in (root / '.github/workflows/android-build.yml').read_text() and 'incoming.artifactView' in gradle and "artifact.file.name == 'api-82.jar'" in gradle and 'was not downloaded' in gradle,
    'Android SDK setup uses current v4 action': 'android-actions/setup-android@v4' in (root / '.github/workflows/android-build.yml').read_text(),
    'APK verifier discovers numbered cmdline-tools apkanalyzer': 'find "$SDK_ROOT/cmdline-tools"' in (root / 'tools/verify_apk.sh').read_text(),
    'legacy API dependency is compileOnly with mirror and upstream repositories': "compileOnly 'de.robv.android.xposed:api:82'" in gradle and 'https://api.xposed.info/' in (root / 'settings.gradle').read_text() and 'https://maven.aliyun.com/repository/public/' in (root / 'settings.gradle').read_text() and 'https://artifactory.appodeal.com/appodeal-public/' in (root / 'settings.gradle').read_text(),
    'API 82 repositories are scoped to its Maven group and ordered by candidate': (root / 'settings.gradle').read_text().index('https://artifactory.appodeal.com/appodeal-public/') < (root / 'settings.gradle').read_text().index('https://maven.aliyun.com/repository/public/') < (root / 'settings.gradle').read_text().index('https://api.xposed.info/') and (root / 'settings.gradle').read_text().count('includeGroup("de.robv.android.xposed")') == 3,
    'CI uploads build diagnostics after failure': 'if: failure()' in (root / '.github/workflows/android-build.yml').read_text() and 'ip26-liquid-glass-build-diagnostics' in (root / '.github/workflows/android-build.yml').read_text(),
    'CI verifies APK before artifact upload': 'tools/verify_apk.sh' in (root / '.github/workflows/android-build.yml').read_text() and (root / '.github/workflows/android-build.yml').read_text().index('tools/verify_apk.sh') < (root / '.github/workflows/android-build.yml').read_text().index('actions/upload-artifact'),
    'fake lifecycle tests cover at least 12 scenarios': 'test_normal_animation_end_blocks_subsequent_frames' in (root / 'tools/test_lifecycle_model.py').read_text(),
    'KernelSU explicitly remains companion scaffold': 'scaffold' in module.lower() and 'LSPosed APK is required' in module,
}
failed = [name for name, ok in checks.items() if not ok]
for name, ok in checks.items():
    print(('PASS' if ok else 'FAIL') + '  ' + name)
print(f'RESULT: {len(checks)-len(failed)}/{len(checks)} static checks passed')
if failed:
    sys.exit(1)
